package com.jiangdg.uac;

/** Pcm data call back
 *
 * @author Created by jiangdg on 2022/9/9
 */
public interface UACAudioCallBack {
    void pcmData(byte[] data);
}
