package com.jiangdg.uvc;

public interface IButtonCallback {
    void onButton(int button, int state);
}
